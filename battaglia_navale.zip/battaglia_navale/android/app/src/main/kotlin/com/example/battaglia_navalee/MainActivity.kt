package com.example.battaglia_navalee

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
